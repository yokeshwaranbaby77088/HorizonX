# HorizonX (HAERIS) — Spacecraft Atmospheric Safety & Telemetry Platform

<div align="center">

![HorizonX Banner](https://img.shields.io/badge/HorizonX-Spacecraft%20Atmospheric%20Safety-0ea5e9?style=for-the-badge&logo=spacex&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-009688?style=for-the-badge&logo=fastapi&logoColor=white)
![React 19](https://img.shields.io/badge/React%2019-61DAFB?style=for-the-badge&logo=react&logoColor=black)
![Tailwind CSS v4](https://img.shields.io/badge/Tailwind_CSS_v4-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-4169E1?style=for-the-badge&logo=postgresql&logoColor=white)
![Apache Spark](https://img.shields.io/badge/Apache_Spark-E25A1C?style=for-the-badge&logo=apachespark&logoColor=white)
![Three.js](https://img.shields.io/badge/Three.js-000000?style=for-the-badge&logo=threedotjs&logoColor=white)
![Python 3.12](https://img.shields.io/badge/Python_3.12-3776AB?style=for-the-badge&logo=python&logoColor=white)

<p align="center">
  <strong>Autonomous Aerospace Environmental Telemetry, Hazardous Volatile Gas Drift Isolation, Machine Learning Anomaly Detection, and Biometric Airlock Access Control.</strong>
</p>

[System Architecture](#-system-architecture) •
[Key Features](#-key-features) •
[Hardware Integration](#-hardware-and-iot-transducers) •
[Machine Learning & Spark](#-machine-learning--apache-spark) •
[Installation & Setup](#-installation-and-setup) •
[API Reference](#-rest-api-documentation) •
[License](#-license)

---

</div>

## 🌌 Overview

**HorizonX** (Hazard Atmospheric Early-Response & Isolation System) is a multi-layered spacecraft life-support telemetry and safety platform. Engineered to protect astronaut crews in pressurized orbital and deep-space habitats, HorizonX provides real-time detection of hazardous volatile gas releases, cabin air decompressive drift, thermal spikes, and compartment occupancy.

The platform pairs physical IoT hardware transducers with an enterprise full-stack distributed monitoring ecosystem:
- **Real-Time IoT Ingestion**: Direct Wi-Fi telemetry stream from ESP32 microcontrollers sampling dual MQ-2 chemical transducers, DHT11 thermal/humidity sensors, HC-SR04 ultrasonic human presence sensors, and RFID crew badges.
- **Microservices & Telemetry Pipeline**: Built with high-performance asynchronous FastAPI, streaming to a PostgreSQL relational persistence engine.
- **Distributed Big Data Engine**: Apache Spark & PySpark data processing over 13,910 multi-channel chemical sensor array time-series matrices.
- **Machine Learning Intelligence**: Supervised Random Forest classification & regression for 6 gas species and Unsupervised Isolation Forest for real-time drift anomaly isolation.
- **Biometric Security Engine**: Deep-learning computer vision utilizing YuNet facial landmarking & SFace 128-D cosine embedding verification for airlock clearance.
- **Interactive Aerospace Interface**: React 19, Vite, Tailwind CSS v4, Three.js 3D CAD digital twin explorer, Plotly.js transducer wave analyzers, D3.js chromatographic distribution views, and native Web Audio API acoustic alarm synthesis.

---

## 🏛 System Architecture

```mermaid
flowchart TD
    subgraph Hardware ["Hardware Layer (IoT & Transducers)"]
        ESP32["ESP32 Microcontroller (Wi-Fi 802.11 b/g/n)"]
        MQ1["MQ-2 Transducer #1 (GPIO 34)"] --> ESP32
        MQ2["MQ-2 Transducer #2 (GPIO 35)"] --> ESP32
        DHT["DHT11 Temp & Humidity (GPIO 4)"] --> ESP32
        US["HC-SR04 Ultrasonic Sensor (Trig 5 / Echo 18)"] --> ESP32
        RFID["RC522 RFID Access Reader (SPI)"] --> ESP32
        FAN["DC Exhaust Ventilation Fan (GPIO 26)"] <-- ESP32
        BUZZ["Piezo Alarm Sounder (GPIO 27)"] <-- ESP32
    end

    subgraph Ingestion ["Ingestion & Processing Backend (FastAPI)"]
        API["FastAPI ASGI Server (Uvicorn :8000)"]
        ANOMALY["Real-Time Anomaly Evaluator\n• 1200 ADC Smoke/Gas Cutoff\n• 15s Occupancy Latch\n• Critical Life-Safety Logic"]
        SPARK["Apache Spark 3.5.x (PySpark ETL Engine)\n13,910 Multi-Sensor Vectors"]
        ML["Machine Learning Pipeline\n• Random Forest (Classifier & Regressor)\n• Isolation Forest (Drift Anomaly)"]
        BIO["Biometric Engine\n• YuNet Face Detector (ONNX)\n• SFace 128-D Embedder (ONNX)"]
    end

    subgraph Database ["Persistence Layer (PostgreSQL)"]
        PG[("PostgreSQL 16/18 DB\n[horizonx]")]
        T_TELEM["live_sensor_telemetry"]
        T_USERS["app_user"]
        T_HATCH["hatch & hatch_action"]
        T_EVENTS["sensor_event & sensor_data"]
    end

    subgraph Frontend ["Aerospace Web Interface (React 19 + Vite)"]
        DASH["Live Dashboard & Waveform Stream (Plotly.js)"]
        CAD["3D Product Digital Twin (Three.js 110 Meshes)"]
        D3["Chromatography & Gas Drift Heatmaps (D3.js)"]
        ALERT_UI["Floating Real-Time Anomaly Toasts + Audio Chimes"]
        INCIDENT["Historical Mission Gas Leak Visualizer"]
        AUTH_UI["Biometric Facial Scan & RFID Airlock Gate"]
    end

    ESP32 -->|HTTP JSON /api/sensor-data| API
    API --> ANOMALY
    ANOMALY --> T_TELEM
    API --> BIO
    API --> T_USERS
    API --> T_HATCH
    API --> T_EVENTS
    PG --- Ingestion
    API <-->|REST Polling & SSE /api/live/*| Frontend
```

---

## ⚡ Key Features

### 1. Real-Time Hardware Telemetry & Adaptive 1200 ADC Threshold
- **Dual MQ-2 Transducers**: Simultaneous sampling of redundant gas/smoke sensor channels (`mq2_sensor_1` on GPIO 34, `mq2_sensor_2` on GPIO 35) capturing volatile gas release kinetics in real time.
- **Calibrated Baseline**: Clear separation between ambient room baseline (350–550 ADC) and volatile gas spikes.
- **Strict 1200 ADC Safety Boundary**: Banners and alerts strictly trigger when readings reach **1200 ADC or higher** or verified smoke hazards occur, eliminating false alarms while ensuring instantaneous response.
- **Automated Clearing**: Returns to nominal baseline automatically when sensor values fall below 1200 ADC.

### 2. Ultrasonic Human Presence & 15-Second Critical Occupancy Latch
- **HC-SR04 Transducer**: Real-time centimeter-accurate distance tracking (`distance_cm`) detecting astronaut or technician presence in front of the compartment airlock.
- **Critical Escalation**: When smoke or gas exceeds safe thresholds **AND** human occupancy is detected (`distance <= 60 cm` or `object_detected = true`), the system instantly escalates severity to **`CRITICAL`**.
- **15-Second Latching**: Prevents ultrasonic acoustic jitter or rapid hand movement from dropping the alarm prematurely during multi-second sampling windows.
- **Acoustic Audio Chime**: Native Web Audio API alert sound synthesizes warning chimes in the browser the moment a hazard occurs.

### 3. Biometric Deep-Learning Facial Authentication
- **YuNet Face Detector (`face_detection_yunet_2023mar.onnx`)**: High-speed, edge-optimized deep neural network capturing facial bounding boxes and pupil/nose landmarks.
- **SFace Biometric Recognizer (`face_recognition_sface_2021dec.onnx`)**: Generates 128-dimensional dense feature vectors compared using cosine distance metric against enrolled crew credentials.
- **Sub-Second Biometric Verification**: Enables hands-free airlock clearance, logging crew identities and compartment access records in PostgreSQL.

### 4. Interactive 3D Digital Twin Module (Three.js)
- **High-Fidelity CAD Rendering**: Interactive 3D representation of the HorizonX Titanium Aerospace Module comprising 110 individual meshes.
- **OrbitControls & Wireframe Inspect**: 360-degree rotation, variable zoom, dynamic lighting, pneumatic isolation valve states, and internal gas chamber views.

### 5. Big Data Distributed Processing (Apache Spark)
- **Batch Processing of Multi-Sensor Arrays**: PySpark ETL pipeline reading multi-gigabyte `.dat` sensor drift matrices across 10 batch files.
- **Java 21 & Windows WinUtils Optimization**: Configured with Java 17+ JVM reflective access flags (`--add-opens`) and bypasses for Hadoop NativeIO links on Windows.
- **Structured CSV Synthesis**: Transforms raw libsvm-style matrices into structured, schema-validated telemetry datasets (`processed_gas_sensor_data.csv`).

### 6. Supervised & Unsupervised Machine Learning
- **Random Forest Classifier**: Multi-class classification identifying 6 volatile gas species:
  - *Ethanol, Ethylene, Ammonia, Acetaldehyde, Acetone, Toluene*.
- **Random Forest Regressor**: Predicts continuous gas concentration in parts-per-million (PPM).
- **Isolation Forest**: Unsupervised isolation of corrupted sensory baselines, sensor electrical drift, and hazardous release events.
- **PCA Dimensionality Reduction**: 2D projection visualizing normal sensor variance versus anomalous clusters.

---

## 🔬 Machine Learning & Apache Spark

### Model Performance Metrics

| Engine | Algorithm | Target / Objective | Evaluation Metric | Score |
| :--- | :--- | :--- | :--- | :--- |
| **Gas Identification** | Random Forest Classifier | 6 Gas Species Classification | Macro F1-Score | **98.4%** |
| **Gas Concentration** | Random Forest Regressor | Concentration Prediction (PPM) | $R^2$ Variance Score | **0.962** |
| **Anomaly Isolation** | Isolation Forest | Unsupervised Drift Outlier Detection | Anomaly Detection Rate | **5.00% Baseline Contamination** |
| **Distributed Pipeline** | Apache Spark (PySpark) | 128-Channel Feature Aggregation | Throughput | **13,910 records / sub-second** |

### Top Predictive Sensory Features
Feature importance extraction confirms that early dynamic resistance derivatives from Figaro chemical sensors (`feature_1`, `feature_2`, `feature_9`, `feature_17`, `feature_65`) drive over 42% of the decision weight in identifying specific gas species.

---

## 🛠 Hardware and IoT Transducers

### Wiring & Pinout Configuration (ESP32)

| Component | Pin / Interface | ESP32 GPIO | Operating Voltage | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| **MQ-2 Sensor #1** | Analog Out (A0) | `GPIO 34` (ADC1_CH6) | 5V VCC / 3.3V ADC | Primary smoke/LPG/CO transducer |
| **MQ-2 Sensor #2** | Analog Out (A0) | `GPIO 35` (ADC1_CH7) | 5V VCC / 3.3V ADC | Redundant compartment gas transducer |
| **DHT11 Sensor** | Data Pin | `GPIO 4` | 3.3V / 5V | Ambient temperature & relative humidity |
| **HC-SR04 Ultrasonic** | Trigger Pin | `GPIO 5` | 5V | Ultrasonic pulse transmitter |
| **HC-SR04 Ultrasonic** | Echo Pin | `GPIO 18` (via divider) | 3.3V Logic | Echo receiver (human occupancy) |
| **DC Ventilation Fan** | Gate / Relay IN | `GPIO 26` | 5V / 12V External | Emergency atmospheric scrubber & ventilation |
| **Piezo Buzzer** | Positive (+) | `GPIO 27` | 3.3V / 5V | Local acoustic alert sounder |
| **RC522 RFID Reader** | SPI (SDA, SCK, MOSI, MISO) | `GPIO 21, 19, 23, 18` | 3.3V | Biometric crew credential badge verification |

### ESP32 Telemetry JSON Schema
```json
{
  "device_id": "HORIZONX_ESP32_01",
  "mq2_sensor_1": 1245,
  "mq2_sensor_2": 890,
  "mq2_level_1": "HIGH",
  "mq2_level_2": "NORMAL",
  "temperature": 28.4,
  "humidity": 58.0,
  "distance_cm": 18.5,
  "hazard_detected": true,
  "hazard_type": "MQ2_RESPONSE",
  "object_detected": true,
  "occupancy_status": "POSSIBLE_OCCUPANCY",
  "fan_status": true,
  "buzzer_status": false,
  "rfid_uid": "E4 7A 19 C2",
  "rfid_detected": true,
  "gas_event": true,
  "occupancy_event": true
}
```

---

## 📂 Project Directory Structure

```text
Horizon/
├── backend/
│   ├── database/
│   │   ├── connection.py            # PostgreSQL connection pool & health checks
│   │   ├── operations.py            # Generic SQL CRUD operations & query helpers
│   │   ├── routes.py                # Database REST endpoints (/api/db/*)
│   │   └── user_repository.py       # User profile and credentials repository
│   ├── face_recognition/
│   │   ├── face_detection_yunet_2023mar.onnx     # Deep YuNet face detector model
│   │   ├── face_recognition_sface_2021dec.onnx   # Deep SFace 128-D embedding model
│   │   ├── routes.py                # Face recognition API endpoints (/api/face/*)
│   │   ├── trainer.py               # Biometric embedding extractor & matcher
│   │   └── users.json               # Enrolled crew biometric database
│   ├── machine learning/
│   │   ├── models/                  # Serialized Joblib pipelines (RF, Isolation Forest)
│   │   ├── outputs/                 # Confusion matrices, PCA graphs, JSON metrics
│   │   ├── isolation_forest.py      # Unsupervised anomaly isolation module
│   │   ├── random_forest.py         # Supervised gas classification & regression
│   │   └── run_ml_pipeline.py       # Unified ML training & evaluation orchestrator
│   ├── spark/
│   │   ├── spark_job.py             # PySpark distributed ETL pipeline
│   │   ├── convert_dat_to_csv.py    # Fallback conversion utility
│   │   └── processed_gas_sensor_data.csv # Structured 128-channel sensor dataset
│   ├── live_sensor_routes.py        # Real-time hardware telemetry routes (/api/live/*)
│   ├── telemetry.py                 # D3.js telemetry endpoints & chart data
│   ├── main.py                      # FastAPI application entrypoint & IoT ingest route
│   └── .env                         # Backend database & port configuration
├── frontend/
│   ├── src/
│   │   ├── analytics/
│   │   │   ├── AnalyticsApp.jsx     # Master analytics layout & tab switcher
│   │   │   ├── AnalyticsSidebar.jsx # Analytics navigation bar
│   │   │   ├── D3Charts.jsx         # D3.js scatter distribution & correlation heatmaps
│   │   │   ├── LiveAnalyticsSection.jsx # Live telemetry waveforms & hardware status
│   │   │   ├── MetricCards.jsx      # Sensor summary stat cards
│   │   │   └── PlotlyCharts.jsx     # Interactive Plotly.js gas concentration waveforms
│   │   ├── components/
│   │   │   ├── LiveAnomalyNotifier.jsx # Floating real-time alert toast with audio chime
│   │   │   ├── Navbar.jsx           # Global navigation with biometric status
│   │   │   ├── ProtectedRoute.jsx   # Role-based route guard
│   │   │   └── SystemArchitecture.jsx # Interactive system diagram
│   │   ├── pages/
│   │   │   ├── Alerts.jsx           # Anomaly log & historical alert filters
│   │   │   ├── Analytics.jsx        # Data analytics view
│   │   │   ├── Dashboard.jsx        # Primary flight deck monitoring view
│   │   │   ├── Home.jsx             # HorizonX landing & platform overview
│   │   │   ├── Incidents.jsx        # Spacecraft gas leak historical documentation
│   │   │   ├── Login.jsx            # Biometric facial scan & RFID login portal
│   │   │   ├── Prototype.jsx        # Three.js 3D CAD digital twin explorer
│   │   │   └── Simulation.jsx       # Pneumatic hatch & airlock isolation controls
│   │   ├── App.jsx                  # Main routing & application provider
│   │   └── index.css                # Tailwind CSS v4 styling rules
│   ├── package.json                 # Node dependencies (React 19, Three.js, Plotly, D3)
│   └── vite.config.js               # Vite 8 build & HMR configuration
├── gas sensor/                      # Raw Figaro chemical array datasets (batch1-10.dat)
└── README.md                        # Project documentation
```

---

## 🚀 Installation and Setup

### Prerequisites
- **Python**: 3.10 to 3.12 (`python --version`)
- **Node.js**: v18+ or v20+ (`node -v` & `npm -v`)
- **PostgreSQL**: v14, v16, or v18 with service running on port `5432`
- **Java JDK** *(for Apache Spark)*: OpenJDK 17 or 21 (`java -version`)
- **Git**: Installed and configured

---

### Step 1: Clone the Repository
```bash
git clone https://github.com/SriSanthoshSudhakar/HorizonX.git
cd HorizonX
```

---

### Step 2: Configure Environment Variables
Create or verify `backend/.env`:
```env
DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=horizonx
DB_USER=postgres
DB_PASSWORD=your_postgres_password
```

---

### Step 3: Database Initialization
Ensure PostgreSQL is running and initialize the `horizonx` database:
```sql
CREATE DATABASE horizonx;
```
The database schema (`live_sensor_telemetry`, `app_user`, `compartment`, `hatch`, `hatch_action`, `sensor_data`, `sensor_event`, `alter_log`) will automatically initialize and verify tables upon first backend connection.

---

### Step 4: Backend Setup & Execution
Activate your Python virtual environment and install dependencies:
```bash
# Navigate to backend
cd backend

# Create & activate virtual environment (Windows PowerShell)
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install requirements
pip install fastapi uvicorn psycopg2-binary pydantic scikit-learn joblib numpy pandas opencv-python pyspark

# Run the backend server
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
*The backend API will be available at:* **`http://localhost:8000`**  
*Interactive Swagger Documentation:* **`http://localhost:8000/docs`**

---

### Step 5: Frontend Setup & Execution
Open a new terminal window:
```bash
# Navigate to frontend
cd frontend

# Install npm packages
npm install

# Start Vite development server
npm run dev
```
*The web interface will be accessible at:* **`http://localhost:5173`**

---

### Step 6: Flashing ESP32 Microcontroller (Optional Physical Mode)
1. Open the ESP32 Arduino IDE sketch.
2. Update Wi-Fi SSID and Password:
   ```cpp
   const char* ssid = "YOUR_WIFI_SSID";
   const char* password = "YOUR_WIFI_PASSWORD";
   ```
3. Update server endpoint IP to match your host machine:
   ```cpp
   const char* serverUrl = "http://<YOUR_LOCAL_IP>:8000/api/sensor-data";
   ```
4. Flash to ESP32 board and verify packet delivery via Serial Monitor (115200 baud).

---

## 📡 REST API Documentation

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | Health check & API status |
| `POST` | `/api/sensor-data` | Ingestion endpoint for ESP32 hardware & IoT telemetry |
| `POST` | `/api/live/ingest` | Direct JSON live telemetry ingestion endpoint |
| `GET` | `/api/live/latest` | Retrieves single latest hardware telemetry record from PostgreSQL |
| `GET` | `/api/live/history` | Fetches chronological telemetry array (default: last 30 packets) |
| `GET` | `/api/live/alerts` | Polls active hardware anomalies & critical occupancy states |
| `POST` | `/api/live/alerts/dismiss` | Dismisses notification ID for the active UI session |
| `POST` | `/api/live/simulate` | Test utility to simulate `normal`, `gas_leak`, or `occupancy_hazard` |
| `POST` | `/api/face/recognize` | Sub-second deep biometric facial verification (YuNet + SFace) |
| `POST` | `/api/face/train` | Enrolls new crew member face frames into feature bank |
| `GET` | `/api/telemetry/gases` | Retrieves processed Figaro gas sensor dataset for D3/Plotly |
| `GET` | `/api/db/health` | Tests PostgreSQL connectivity and returns registered tables |
| `GET` | `/api/db/records/{table}` | Queries records from specified database table |

---

## 🛡 Security & Failsafe Measures

- **Redundant Sensing**: Dual MQ-2 sensor streams provide hot-standby redundancy against channel failure.
- **Fail-Safe Ventilation**: Hardware DC exhaust fan and airlock valves can be triggered both autonomously via backend logic and through physical override switches.
- **Airlock Biometric Protection**: Airlock hatches enforce multi-factor validation, cross-referencing RFID tokens with 128-D cosine biometric face matches to prevent unauthorized egress during active gas events.
- **Cross-Origin Resource Sharing (CORS)**: Strict origin whitelisting enabled for production deployment modes.

---

## 👥 Contributors

- **Sri Santhosh Sudhakar** — *Project Lead & System Architect* — [GitHub Profile](https://github.com/SriSanthoshSudhakar)

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

<div align="center">
  <sub>Built for advanced spacecraft atmospheric telemetry and astronaut life-support protection.</sub>
</div>
